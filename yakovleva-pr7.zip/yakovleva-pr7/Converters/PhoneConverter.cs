﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;

namespace yakovleva_pr7.Converters
{
    public class PhoneConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is string phone && !string.IsNullOrEmpty(phone))
            {
                // Убираем все нецифровые символы
                var digits = System.Text.RegularExpressions.Regex.Replace(phone, @"\D", "");

                if (digits.Length == 11)
                {
                    if (digits.StartsWith("7") || digits.StartsWith("8"))
                    {
                        return $"+7 ({digits.Substring(1, 3)}) {digits.Substring(4, 3)}-{digits.Substring(7, 2)}-{digits.Substring(9, 2)}";
                    }
                }
                else if (digits.Length == 10)
                {
                    return $"+7 ({digits.Substring(0, 3)}) {digits.Substring(3, 3)}-{digits.Substring(6, 2)}-{digits.Substring(8, 2)}";
                }
            }
            return value;
        }
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is string phone)
                return System.Text.RegularExpressions.Regex.Replace(phone, @"\D", "");
            return value;
        }
    }
}
